﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GhostScript : MonoBehaviour
{
    #region variables
    public float speedMultiplier = 0;
    public Vector3Int direction;
    private Vector3Int Direction
    {
        get
        {
            return direction;
        }
        set
        {
            direction = value;
            if (!Frightened)
                UpdateEyes(direction);
        }
    }
    public bool Frightened
    {
        get
        {
            return frightened;
        }
        set
        {
            if (value == true)
            {
                frightened = (!Dead && gotOut) ? true : false;
                if (frightened == true)
                {
                    speedMultiplier = 0.5f;
                    bodyAnim.SetBool("Frightened", false);
                    GameController.Controller.PlayGhostsSound(false);
                    GameController.Controller.PlayGhostsSoundF(true);
                }
            } 
            else
            {
                speedMultiplier = 1;
                frightened = false;
            }
            bodyAnim.SetBool("Frightened", frightened);
        }
    }
    protected bool passDoor;
    protected Vector3 target;
    protected bool dead;
    protected bool Dead
    {
        get
        {
            return dead;
        }
        set
        {
            dead = value;
            if (dead == true)
            {
                Physics2D.IgnoreCollision(coll, PacManScript.PacMan.Collider, true);
                speedMultiplier = 1.5f;
                Frightened = false;
                passDoor = true;
            }
            else
            {
                Body.SetActive(true);
                Physics2D.IgnoreCollision(coll, PacManScript.PacMan.Collider, false);
                speedMultiplier = 1;
            }
        }
    }
    bool canTeleport = true;
    protected bool gotOut = false;
    bool firstTileB;
    bool frightened;
    TileDetector currentTile, firstTile;
    Vector3 startPosition;
    Vector3Int startDirection;
    List<TileDetector> tiles;
    Collider2D coll;

    [SerializeField]
    float velocity;
    [SerializeField]
    float teleportTime;
    [SerializeField]
    protected Transform scatterTarget, deadTarget;
    [SerializeField]
    List<GameObject> teleporters;
    [SerializeField]
    protected Animator bodyAnim;
    [SerializeField]
    Animator eyesAnim;
    [SerializeField]
    GameObject Eyes, Body;
    [SerializeField]
    AudioSource eatGhostAudio;
    #endregion

    protected virtual void Start()
    {
        Physics2D.IgnoreLayerCollision((int)GameController.Layers.Ghosts, (int)GameController.Layers.PacMan, false);
        gameObject.SetActive(true);
        gotOut = false;
        tiles = new List<TileDetector>();
        coll = GetComponent<Collider2D>();
        Eyes.SetActive(true);
        Body.SetActive(true);
        startPosition = transform.position;
        startDirection = Direction;
    }

    protected void FixedUpdate()
    {
        if (Dead)
            passDoor = true;
        else if (!Dead && gotOut)
            passDoor = false;
        if (Dead && Vector3.Distance(transform.position, deadTarget.position) <= 0.1f)
        {
            passDoor = true;
            frightened = false;
            Dead = false;
            Eyes.SetActive(true);
            Body.SetActive(true);
            Direction = Vector3Int.up;
        }
        if (frightened)
        {
            Eyes.SetActive(false);
        }
        else
        {
            Eyes.SetActive(true);
        }

        Walk();
    }

    void ChangeDirection()
    {
        tiles.Clear();
        tiles.AddRange(currentTile.RemoveInverseNeighbor(Direction, target, passDoor));
        if (tiles.Count == 0)
        {
            currentTile = null;
            return;
        }

        if (!frightened)
        {
            tiles.Sort();
            if (tiles.Count > 1 && tiles[0].F == tiles[1].F)
            {
                //Chooses the closest way to the target when intercepts a intersection
                if (CalculateDirection(tiles[1]) == Vector3Int.up)
                    ChangeSpots(tiles);
                else if (CalculateDirection(tiles[1]) == Vector3Int.left && CalculateDirection(tiles[0]) != Vector3Int.up)
                    ChangeSpots(tiles);
                else if (CalculateDirection(tiles[1]) == Vector3Int.down && CalculateDirection(tiles[0]) != Vector3Int.left)
                    ChangeSpots(tiles);
            }
            Direction = CalculateDirection(tiles[0]);
        }
        else
        {
            //Chooses randomly a direction when intercepts a intersection
            int index = new System.Random().Next(0, tiles.Count);
            Direction = CalculateDirection(tiles[index]);
            //it doesn't need to update its eyes because it doesn't have 'em when frightened
        }
        
    }

    Vector3Int CalculateDirection(TileDetector tile)
    {
        Vector3Int direction = Vector3Int.RoundToInt(tile.transform.position - currentTile.transform.position);
        return direction;
    }

    void Walk()
    {
        transform.position += (Vector3)Direction * velocity * Time.fixedDeltaTime * speedMultiplier;
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.CompareTag("IntersectionADoor") && Vector3.Distance(transform.position, collision.transform.position) <= 0.1f && Direction == Vector3.up)
        {
            if (GameController.mode == GameController.Mode.Scatter)
                Direction = Vector3Int.left;
            else if (GameController.mode == GameController.Mode.Chase)
                Direction = Vector3Int.right;
            passDoor = false;
            gotOut = true;
            return;
        }
        if (collision.CompareTag("IntersectionADoor") && !Dead && Vector3.Distance(transform.position, collision.transform.position) <= 0.07f && !gotOut)
        {
            if (GameController.mode == GameController.Mode.Scatter)
                Direction = Vector3Int.left;
            else if (GameController.mode == GameController.Mode.Chase)
                Direction = Vector3Int.right;
            passDoor = false;
            gotOut = true;
            return;
        }
        else if (collision.CompareTag("IntersectionBDoor") && Dead && Vector3.Distance(transform.position, collision.transform.position) <= 0.07f)
        {
            Direction = Vector3Int.up;
            Dead = false;
            passDoor = true;
            gotOut = false;
            return;
        }
        else if (collision.CompareTag("IntersectionBDoor") && !Dead && Vector3.Distance(transform.position, collision.transform.position) <= 0.07f)
        {
            Direction = Vector3Int.up;
            passDoor = true;
            gotOut = false;
            return;
        }
        if (collision.CompareTag("Teleporter") && canTeleport)
        {
            canTeleport = false;

            if (collision.gameObject == teleporters[0])
                transform.position = teleporters[1].transform.position;
            else
                transform.position = teleporters[0].transform.position;

            StartCoroutine(TeleportTime(teleportTime));
        }

        TileDetector tile = collision.GetComponent<TileDetector>();

        if (tile != null && tile != currentTile && tile.neighbors.Count > 0 && Vector3.Distance(transform.position, collision.transform.position) <= 0.07f)
        {
            if (collision.tag.Contains("Intersection") || collision.CompareTag("GhostHouse"))
            {
                if (Mathf.Abs(Direction.x) == 1)
                    transform.position = new Vector3(tile.transform.position.x, transform.position.y);
                else if (Mathf.Abs(Direction.y) == 1)
                    transform.position = new Vector3(transform.position.x, tile.transform.position.y);
                currentTile = tile;
                if (firstTileB)
                {
                    firstTile = currentTile;
                    firstTileB = false;
                }
                ChangeDirection();
            }
        }
    }

    protected void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject. CompareTag("PacMan") && frightened)
        {
            eatGhostAudio.Play();
            passDoor = true;
            frightened = false;
            Dead = true;
            int test = PacManScript.PacMan.points;
            PacManScript.PacMan.points += 200 * PacManScript.PacMan.pointMultiplier;
            print(PacManScript.PacMan.points - test);
            PacManScript.PacMan.pointMultiplier *= 2;
            Eyes.SetActive(true);
            Body.SetActive(false);
            print(gameObject.name + ": " + passDoor);
        }
        else if (collision.gameObject.CompareTag("PacMan") && !frightened && !Dead)
        {
            eatGhostAudio.Play();
            PacManScript.PacMan.Lifes--;
            GameController.Controller.PlayGhostsSound(false);
            GameController.Controller.PlayGhostsSoundF(false);
            Physics2D.IgnoreLayerCollision((int)GameController.Layers.Ghosts, (int)GameController.Layers.PacMan, true);
        }
    }

    public void InvertDirection()
    {
        if (gotOut && !Dead)
        {
            currentTile = null;
            Direction *= -1;
        }     
    }

    public void Restart()
    {
        speedMultiplier = 0;
        Direction = startDirection;
        currentTile = firstTile;
        transform.position = startPosition;
        speedMultiplier = 1;
        Dead = false;
        Frightened = false;
        passDoor = false;
        gotOut = false;
        StopAllCoroutines();
        Start();
    }

    private void UpdateEyes(Vector3Int direction)
    {
        eyesAnim.SetInteger("XAxis", direction.x);
        eyesAnim.SetInteger("YAxis", direction.y);
    }

    void ChangeSpots<T>(List<T> list)
    {
        T temp = list[0];
        list[0] = list[1];
        list[1] = temp;
    }

    IEnumerator TeleportTime(float time)
    {
        yield return new WaitForSeconds(time);
        canTeleport = true;
    }
}